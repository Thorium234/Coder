Vibe Coder Go rewrite

Files:
  vibe_coder.go
  builtin_projects.json

Install Go and VS Code, and ensure the `code` command is on PATH.

From this folder:
  go mod init vibe-coder
  go get github.com/go-vgo/robotgo
  go run .

Flags:
  --online
  --hours 3
  --slowdown 1.5
  --projects-dir ./my_snippets
  --keep
  --out ~/vibe_projects
  --keep-windows
  --window-wait 12
  --no-focus-check

The project snippets are Python source because this program's purpose is to
simulate typing Python projects into VS Code. The controller itself is Go.

Safety note: automation sends keyboard input to the foreground window. Keep the
intended editor focused and test with a short snippet first. On non-Windows
platforms, window-title verification and keyboard pause hotkeys are not
implemented in this initial Go port. Ctrl+C stops it.
