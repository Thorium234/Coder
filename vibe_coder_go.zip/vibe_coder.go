// vibe_coder.go: Go rewrite of vibe_coder.py's project typing controller.
// Requires robotgo and VS Code's `code` command. Use at your own risk.
package main

import (
  "embed"
  "encoding/json"
  "flag"
  "fmt"
  "io"
  "math/rand"
  "net/http"
  "net/url"
  "os"
  "os/exec"
  "path/filepath"
  "regexp"
  "runtime"
  "sort"
  "strings"
  "time"

  "github.com/go-vgo/robotgo"
)

//go:embed builtin_projects.json
var builtinFS embed.FS

type Project struct { Name string `json:"name"`; Filename string `json:"filename"`; Code string `json:"code"` }
type Config struct { keep, online, keepWindows, noFocus bool; out, projectsDir string; hours, slowdown, windowWait float64 }
const typoChance=.035
const thinkChance=.05
var neighbours=map[rune]string{'a':"qwsz",'b':"vghn",'c':"xdfv",'d':"serfcx",'e':"wsdr",'f':"drtgvc",'g':"ftyhbv",'h':"gyujnb",'i':"ujko",'j':"huikmn",'k':"jiolm",'l':"kop",'m':"njk",'n':"bhjm",'o':"iklp",'p':"ol",'q':"wa",'r':"edft",'s':"awedxz",'t':"rfgy",'u':"yhji",'v':"cfgb",'w':"qase",'x':"zsdc",'y':"tghu",'z':"asx"}
var scale=1.0

func loadBuiltins() ([]Project,error) { b,e:=builtinFS.ReadFile("builtin_projects.json"); if e!=nil{return nil,e}; var p []Project; e=json.Unmarshal(b,&p); return p,e }
func slug(s string)string { r:=regexp.MustCompile(`[^a-z0-9]+`); s=r.ReplaceAllString(strings.ToLower(s),"_"); return strings.Trim(strings.TrimSpace(s),"_") }
func clean(s string)string { s=strings.ReplaceAll(s,"\r\n","\n"); s=strings.ReplaceAll(s,"\r","\n"); s=strings.ReplaceAll(s,"\t","    "); lines:=strings.Split(s,"\n"); for i:=range lines {lines[i]=strings.TrimRight(lines[i]," ")} ; return strings.Trim(strings.Join(lines,"\n"),"\n")+"\n" }
func delay(a,b float64){time.Sleep(time.Duration((a+rand.Float64()*(b-a))*scale*float64(time.Second)))}
func press(ch string){ if ch=="\n" {robotgo.KeyTap("enter")} else if ch=="\t" {robotgo.KeyTap("tab")} else {robotgo.TypeStr(ch)} }
func wrong(r rune)string { s:=neighbours[rune(strings.ToLower(string(r))[0]]; if s==""{return ""}; x:=string(s[rand.Intn(len(s))]); if r>='A'&&r<='Z'{return strings.ToUpper(x)};return x }
func typeLine(line string){ for _,r:=range line { if (r>='a'&&r<='z'||r>='A'&&r<='Z')&&rand.Float64()<typoChance {w:=wrong(r);if w!="" {press(w);delay(.2,.5);robotgo.KeyTap("backspace");delay(.15,.3)}};press(string(r));delay(.2,.5);if rand.Float64()<thinkChance{delay(1.5,4)} } }
func opensBlock(s string)bool { s=regexp.MustCompile(`\s+#.*$`).ReplaceAllString(s,"");s=strings.TrimSpace(s);return strings.HasSuffix(s,":")||strings.HasSuffix(s,"{")||strings.HasSuffix(s,"(")||strings.HasSuffix(s,"[") }
func typeCode(code string){ lines:=strings.Split(clean(code),"\n"); indent:=0; for i,line:=range lines {content:=strings.TrimSpace(line);if content!="" {target:=len(line)-len(strings.TrimLeft(line," ")); levels:=(target-indent)/4; if levels>0 {for j:=0;j<levels;j++{robotgo.KeyTap("tab");delay(.2,.4)}} else if levels<0 {for j:=0;j< -levels;j++{robotgo.KeyTap("tab", "shift");delay(.2,.4)}};indent=target;typeLine(content)};if i<len(lines)-1{press("\n");if opensBlock(content){indent+=4};delay(1,2.6)}} }
func readLocal(dir string)[]Project { var p []Project;if dir==""{return p};files,_:=filepath.Glob(filepath.Join(dir,"*.py"));sort.Strings(files);for _,f:=range files{b,e:=os.ReadFile(f);if e==nil{p=append(p,Project{Name:slug(filepath.Base(f[:len(f)-3])),Filename:filepath.Base(f),Code:string(b)})}};return p }
func codeCommand()string {p,e:=exec.LookPath("code");if e==nil{return p};p,e=exec.LookPath("code.cmd");if e==nil{return p};return ""}
func newFolder(root,name string)(string,error){for n:=1;n<10000;n++{f:=filepath.Join(root,fmt.Sprintf("%03d_%s",n,slug(name)));if _,e:=os.Stat(f);os.IsNotExist(e){return f,os.Mkdir(f,0755)}};return "",fmt.Errorf("could not allocate project folder")}
func fetchOnline()(*Project,error){topics:=[]string{"game","cli tool","text adventure","automation script","web scraper","chat bot","productivity tool","puzzle game","file utility","calculator","quiz app"};topic:=topics[rand.Intn(len(topics))];q:=url.QueryEscape(topic+" language:python");req,_:=http.NewRequest("GET","https://api.github.com/search/repositories?q="+q+"&sort=stars&per_page=20",nil);req.Header.Set("User-Agent","vibe-coder-go");req.Header.Set("Accept","application/vnd.github+json");if t:=os.Getenv("GITHUB_TOKEN");t!=""{req.Header.Set("Authorization","Bearer "+t)};resp,e:=http.DefaultClient.Do(req);if e!=nil{return nil,e};defer resp.Body.Close();var search struct{Items []struct{Name,FullName,HTMLURL string;Description *string} `json:"items"`};if resp.StatusCode!=200{return nil,fmt.Errorf("GitHub search status %s",resp.Status)};json.NewDecoder(resp.Body).Decode(&search);for _,repo:=range search.Items{url:="https://api.github.com/repos/"+repo.FullName+"/contents";r,_:=http.NewRequest("GET",url,nil);r.Header.Set("User-Agent","vibe-coder-go");r.Header.Set("Accept","application/vnd.github+json");if t:=os.Getenv("GITHUB_TOKEN");t!=""{r.Header.Set("Authorization","Bearer "+t)};rr,err:=http.DefaultClient.Do(r);if err!=nil{continue};var listing []struct{Name string `json:"name"`;Size int `json:"size"`;Download string `json:"download_url"`};json.NewDecoder(rr.Body).Decode(&listing);rr.Body.Close();for _,f:=range listing{if strings.HasSuffix(f.Name,".py")&&f.Size>=4000&&f.Size<=40000&&f.Download!=""{res,err:=http.Get(f.Download);if err!=nil{continue};b,_:=io.ReadAll(res.Body);res.Body.Close();code:=string(b);if len(strings.Split(code,"\n"))>=100{return &Project{Name:slug(repo.Name),Filename:f.Name,Code:"# Source: "+repo.HTMLURL+"\n# Check the original repository's licence before reuse.\n\n"+code},nil}}};return nil,fmt.Errorf("no suitable repository file found")}
func run(c Config)error{built,e:=loadBuiltins();if e!=nil{return e};pool:=append(built,readLocal(c.projectsDir)...);if len(pool)==0{return fmt.Errorf("no projects loaded")};var root string;if c.keep{root=c.out;if root==""{root="~/vibe_projects"};root=strings.Replace(root,"~",os.Getenv("HOME"),1);os.MkdirAll(root,0755);fmt.Println("Keeping completed files in",root)}else{root,e=os.MkdirTemp("","vibe_coder_");if e!=nil{return e};defer os.RemoveAll(root);fmt.Println("Temporary project files are removed on exit")};code:=codeCommand();if code==""{return fmt.Errorf("VS Code 'code' command not found")};fmt.Println("Starting in 10 seconds. Move to VS Code and leave the target editor focused.");for i:=10;i>0;i--{fmt.Printf("%d ",i);time.Sleep(time.Second)};fmt.Println();started:=time.Now();round:=0;for{if c.hours>0&&time.Since(started)>time.Duration(c.hours*float64(time.Hour)){fmt.Println("Time limit reached");return nil};var p Project;if c.online{if online,err:=fetchOnline();err==nil{p=*online}else{fmt.Println("Online mode failed:",err)}};if p.Code==""{p=pool[rand.Intn(len(pool))]};folder,e:=newFolder(root,p.Name);if e!=nil{return e};file:=filepath.Join(folder,p.Filename);if e=os.WriteFile(file,[]byte{},0644);e!=nil{return e};round++;fmt.Printf("\n=== Project %d: %s (%d lines)\n",round,p.Name,len(strings.Split(p.Code,"\n")));cmd:=exec.Command(code,"-n",folder,file);if e=cmd.Start();e!=nil{return e};time.Sleep(time.Duration(c.windowWait*float64(time.Second)));if runtime.GOOS=="windows"&&!c.noFocus{title:=robotgo.GetTitle();if !strings.Contains(title,p.Filename)||!strings.Contains(title,filepath.Base(folder)){return fmt.Errorf("focus safety check failed; active title is %q",title)}};delay(1,2);typeCode(strings.TrimLeft(p.Code,"\n"));delay(2,4);robotgo.KeyTap("s","ctrl");delay(2,4);if !c.keepWindows{robotgo.KeyTap("w","shift","ctrl")};if !c.keep&& !c.keepWindows{time.Sleep(2*time.Second);os.RemoveAll(folder)};fmt.Println("Finished",p.Name);delay(8,20)}}
func main(){rand.Seed(time.Now().UnixNano());var c Config;flag.BoolVar(&c.keep,"keep",false,"keep finished projects");flag.StringVar(&c.out,"out","~/vibe_projects","output directory when --keep is used");flag.BoolVar(&c.online,"online",false,"fetch public Python projects from GitHub");flag.Float64Var(&c.hours,"hours",0,"stop after this many hours, zero means run indefinitely");flag.Float64Var(&c.slowdown,"slowdown",1,"slowdown multiplier");flag.StringVar(&c.projectsDir,"projects-dir","","also type Python files from this folder");flag.BoolVar(&c.keepWindows,"keep-windows",false,"leave VS Code windows open");flag.Float64Var(&c.windowWait,"window-wait",12,"wait time after opening VS Code");flag.BoolVar(&c.noFocus,"no-focus-check",false,"disable Windows window-title check");flag.Parse();scale=c.slowdown;if scale<.2{scale=.2};if err:=run(c);err!=nil{fmt.Fprintln(os.Stderr,"Stopped:",err);os.Exit(1)}}
