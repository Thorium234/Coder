# Vibe Coder C++

C++17 controller for opening Python project files in VS Code and simulating keyboard input. This implementation is a partial port. It includes bundled projects, local Python file loading, runtime and speed options, dry-run inspection, and folder retention/cleanup.

## Requirements
- C++17 compiler (GCC, Clang or MSVC)
- Visual Studio Code and `code` CLI
- Linux: `xdotool` for keyboard typing and active-window-title checks

## Build

### CMake
```sh
cmake -S . -B build
cmake --build build
```

### Direct compiler (Linux)
```sh
g++ -std=c++17 -O2 src/main.cpp -o vibe_coder
```

## Usage
```sh
./vibe_coder --dry-run
./vibe_coder --hours 0.1
./vibe_coder --slowdown 1.5
./vibe_coder --projects-dir ./my_projects
./vibe_coder --keep --out ./saved
./vibe_coder --keep-windows
./vibe_coder --help
```

## Safety and limitations
- Start with `--dry-run` and supervise all automation.
- Focus checking is best-effort and checks window title before each line, not each keystroke.
- Linux implementation requires `xdotool`; focus detection and typing depend on the desktop environment.
- Windows implementation is a basic Unicode SendInput path; focus title checks are rudimentary.
- Online GitHub retrieval, API-based generation, hotkey pause/resume, typo simulation and cross-platform macOS automation are not implemented in this port.
- The code has not been fully tested on every target OS. Keyboard automation can type into the wrong window. Use at your own risk.
