#include <algorithm>
#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <random>
#include <sstream>
#include <string>
#include <thread>
#include <vector>
#include <cstdlib>
#ifdef _WIN32
#include <windows.h>
#endif
namespace fs = std::filesystem;
struct Project { std::string name, filename, code; };
std::mt19937 rng(std::random_device{}());
int randInt(int a,int b){return std::uniform_int_distribution<int>(a,b)(rng);} 
double randDouble(double a,double b){return std::uniform_real_distribution<double>(a,b)(rng);}
void waitMs(int ms){std::this_thread::sleep_for(std::chrono::milliseconds(ms));}
std::string readFile(const fs::path&p){std::ifstream f(p,std::ios::binary);std::ostringstream s;s<<f.rdbuf();return s.str();}
// Minimal JSON string decoder for the bundled project array, sufficient for its string fields.
std::string decode(const std::string&s,size_t &i){std::string o; if(s[i]!='"')return o; i++; while(i<s.size()){char c=s[i++];if(c=='"')break;if(c=='\\'&&i<s.size()){char e=s[i++];switch(e){case 'n':o+='\n';break;case 'r':o+='\r';break;case 't':o+='\t';break;case 'b':o+='\b';break;case 'f':o+='\f';break;case '\\':o+='\\';break;case '"':o+='"';break;case '/':o+='/';break;default:o+=e;}}else o+=c;}return o;}
std::vector<Project> parseProjects(const std::string&s){std::vector<Project> out;size_t i=0;while(i<s.size()){if(s[i]!='{'){i++;continue;}i++;Project p;while(i<s.size()&&s[i]!='}'){if(s[i]=='"'){size_t k=i;std::string key=decode(s,i);while(i<s.size()&&s[i]!=':')i++;if(i<s.size())i++;while(i<s.size()&&(s[i]==' '||s[i]=='\n'||s[i]=='\r'))i++;if(i<s.size()&&s[i]=='"'){std::string val=decode(s,i);if(key=="name")p.name=val;else if(key=="filename")p.filename=val;else if(key=="code")p.code=val;}else {while(i<s.size()&&s[i]!=','&&s[i]!='}')i++;} (void)k;}else i++;}if(!p.name.empty()&&!p.filename.empty()&&!p.code.empty())out.push_back(p);if(i<s.size())i++;}return out;}
std::string activeTitle(){
#ifdef _WIN32
 HWND h=GetForegroundWindow();char b[512]{};GetWindowTextA(h,b,sizeof(b));return b;
#elif defined(__linux__)
 const char*cmd="xdotool getwindowfocus getwindowname 2>/dev/null";FILE*f=popen(cmd,"r");if(!f)return {};char b[512]{};fgets(b,sizeof(b),f);pclose(f);return b;
#else
 return {};
#endif
}
bool focusOK(const std::string&filename,const std::string&folder){std::string t=activeTitle();return t.find(filename)!=std::string::npos||t.find(folder)!=std::string::npos;}
bool typeText(const std::string&text){
#ifdef _WIN32
 for(unsigned char c:text){INPUT in[2]{};in[0].type=INPUT_KEYBOARD;in[0].ki.wVk=0;in[0].ki.wScan=c;in[0].ki.dwFlags=KEYEVENTF_UNICODE;in[1]=in[0];in[1].ki.dwFlags=KEYEVENTF_UNICODE|KEYEVENTF_KEYUP;if(SendInput(2,in,sizeof(INPUT))!=2)return false;waitMs(randInt(35,90));}return true;
#elif defined(__linux__)
 std::string escaped;for(char c:text){if(c=='\n')escaped+="\n";else if(c=='\t')escaped+="\t";else escaped+=c;}std::string cmd="xdotool type --clearmodifiers --delay 35 -- "+std::string("'");for(char c:escaped){if(c=='\'')cmd+="'\\''";else cmd+=c;}cmd+="'";return std::system(cmd.c_str())==0;
#else
 (void)text;std::cerr<<"Typing automation is not implemented for this platform.\n";return false;
#endif
}
void usage(){std::cout<<"Vibe Coder C++\nOptions: --dry-run --hours N --slowdown N --projects-dir DIR --keep --out DIR --keep-windows --window-wait N --no-focus-check --help\n";}
int main(int argc,char**argv){double hours=0,slow=1.0;int windowWait=12;bool dry=false,keep=false,keepWindows=false,focusCheck=true;fs::path localDir,outDir=fs::temp_directory_path()/"vibe_coder_cpp";for(int i=1;i<argc;i++){std::string a=argv[i];auto val=[&](){if(i+1>=argc){usage();exit(2);}return std::string(argv[++i]);};if(a=="--help"){usage();return 0;}else if(a=="--dry-run")dry=true;else if(a=="--hours")hours=std::stod(val());else if(a=="--slowdown")slow=std::stod(val());else if(a=="--projects-dir")localDir=val();else if(a=="--keep")keep=true;else if(a=="--out")outDir=val();else if(a=="--keep-windows")keepWindows=true;else if(a=="--window-wait")windowWait=std::stoi(val());else if(a=="--no-focus-check")focusCheck=false;else{std::cerr<<"Unknown option: "<<a<<"\n";usage();return 2;}}if(hours<0||slow<=0||windowWait<0){std::cerr<<"Invalid numeric option.\n";return 2;}
 fs::path data=fs::path(argv[0]).parent_path()/"projects"/"builtin_projects.json";if(!fs::exists(data))data="projects/builtin_projects.json";std::vector<Project> projects=parseProjects(readFile(data));if(projects.empty()){std::cerr<<"Could not load built-in projects.\n";return 1;}
 if(!localDir.empty()&&fs::exists(localDir)){for(auto&f:fs::directory_iterator(localDir))if(f.is_regular_file()&&f.path().extension()==".py")projects.push_back({f.path().stem().string(),f.path().filename().string(),readFile(f.path())});}
 if(dry){std::cout<<"Dry run: "<<projects.size()<<" project(s) loaded.\n";for(auto&p:projects)std::cout<<"  "<<p.name<<" ("<<p.filename<<", "<<p.code.size()<<" bytes)\n";return 0;}
 std::cout<<"Keyboard automation will begin in 10 seconds. Keep the intended editor focused.\n";for(int i=10;i>0;i--){std::cout<<i<<"...\r"<<std::flush;waitMs(1000);}std::cout<<"\n";auto start=std::chrono::steady_clock::now();size_t idx=0;while(hours==0||std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<hours*3600){Project p=projects[idx++%projects.size()];fs::create_directories(outDir);fs::path folder=outDir/(p.name+"_"+std::to_string(std::chrono::system_clock::now().time_since_epoch().count()));fs::create_directories(folder);fs::path file=folder/p.filename;std::ofstream(file)<<"";
#ifdef _WIN32
 std::string launch="code -n \""+folder.string()+"\" \""+file.string()+"\"";
#else
 std::string launch="code -n \""+folder.string()+"\" \""+file.string()+"\"";
#endif
 if(std::system(launch.c_str())!=0){std::cerr<<"Could not launch VS Code.\n";if(!keep)fs::remove_all(folder);return 1;}waitMs(windowWait*1000);std::istringstream lines(p.code);std::string line;bool stopped=false;while(std::getline(lines,line)){if(focusCheck&&!focusOK(p.filename,folder.filename().string())){std::cerr<<"Focus check failed. Stopping this project. Active title: "<<activeTitle()<<"\n";stopped=true;break;}if(!typeText(line+"\n")){stopped=true;break;}waitMs((int)(randInt(400,1200)*slow));}if(!keepWindows)std::system("code --reuse-window --command workbench.action.closeWindow >/dev/null 2>&1");if(!keep)fs::remove_all(folder);if(stopped)break;waitMs(randInt(5,12)*1000);}return 0;}
