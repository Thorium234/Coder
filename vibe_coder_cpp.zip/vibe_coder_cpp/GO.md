# C and C++ Port Guide

## C++ version
This archive contains the C++17 rewrite. C++ was chosen over C for filesystem handling, strings, project records and standard-library facilities. It is not a separate C implementation.

## Build prerequisites
Install a C++17 toolchain and CMake. On Linux, install `xdotool` if keyboard automation is needed and ensure the `code` launcher is in PATH.

## Build using CMake
```sh
cmake -S . -B build
cmake --build build
```

Or compile directly on Linux:
```sh
g++ -std=c++17 -O2 src/main.cpp -o vibe_coder
```

## Test project discovery
```sh
./vibe_coder --dry-run
```
Dry-run lists project entries without launching VS Code or typing.

## Common options
- `--hours N`: runtime in hours; zero means no runtime limit in this implementation.
- `--slowdown N`: multiplier for delay between lines.
- `--projects-dir DIR`: load `.py` files from a directory.
- `--keep`: retain generated files.
- `--out DIR`: choose output directory.
- `--keep-windows`: skip the attempted VS Code window close action.
- `--window-wait N`: wait in seconds after launch.
- `--no-focus-check`: disable best-effort focus check. Not recommended.
- `--dry-run`: list loaded projects only.

## Linux
The automation uses `xdotool` shell commands. Install it through your distribution's package manager and use a desktop session where simulated keyboard input is permitted. Focus-title checks rely on the `xdotool getwindowfocus getwindowname` command.

## Windows
The typing path uses Win32 `SendInput`. This initial port is not fully verified. Check focus, permissions and behavior before using it. A VS Code CLI installation is expected.

## Limitations
This is a partial port, not feature parity with the Python source. It lacks GitHub project discovery, API-based generation, pause/resume hotkeys, macOS support, and intentional typo/correction simulation. Focus checking is not a security guarantee and is performed at line boundaries.

## Safety
Do not leave the program unattended. Test with `--dry-run`, supervise the desktop, and stop the process if input is sent to an unintended window. Avoid `--no-focus-check`.
