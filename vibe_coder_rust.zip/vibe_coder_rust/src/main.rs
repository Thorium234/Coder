use clap::Parser;
use enigo::{Enigo, Keyboard, Key, Direction, Settings};
use rand::{seq::SliceRandom, Rng};
use serde::Deserialize;
use std::{fs, path::{Path, PathBuf}, process::{Command, Stdio}, thread, time::{Duration, Instant}};

#[derive(Parser, Debug)]
#[command(name="vibe-coder", about="A controlled Python project typing automation tool for VS Code")]
struct Args {
    #[arg(long)] keep: bool,
    #[arg(long, default_value="~/vibe_projects")] out: String,
    #[arg(long)] online: bool,
    #[arg(long, default_value_t=0.0)] hours: f64,
    #[arg(long, default_value_t=1.0)] slowdown: f64,
    #[arg(long)] projects_dir: Option<PathBuf>,
    #[arg(long)] keep_windows: bool,
    #[arg(long, default_value_t=8.0)] window_wait: f64,
    #[arg(long)] no_focus_check: bool,
    #[arg(long)] dry_run: bool,
    #[arg(long, default_value_t=0.5)] char_delay: f64,
}

#[derive(Clone, Deserialize)] struct Project { name: String, filename: String, code: String }
static STOP: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);

fn slug(s: &str) -> String {
    let v: String = s.to_lowercase().chars().map(|c| if c.is_ascii_alphanumeric(){c}else{'_'}).collect();
    let v = v.trim_matches('_').to_string(); if v.is_empty(){"project".into()}else{v.chars().take(40).collect()}
}
fn expand(p: &str) -> PathBuf { if p.starts_with("~/") { if let Ok(h)=std::env::var("HOME"){return PathBuf::from(h).join(&p[2..]);} } PathBuf::from(p) }
fn projects() -> Vec<Project> { serde_json::from_str(include_str!("projects.json")).unwrap_or_default() }
fn local_projects(dir: &Path) -> Vec<Project> {
    let mut out=Vec::new(); if let Ok(entries)=fs::read_dir(dir) { for e in entries.flatten() { let p=e.path(); if p.extension().and_then(|x|x.to_str())==Some("py") { if let Ok(code)=fs::read_to_string(&p) { let file=p.file_name().unwrap_or_default().to_string_lossy().into_owned(); let name=p.file_stem().unwrap_or_default().to_string_lossy().into_owned(); out.push(Project{name:slug(&name),filename:file,code}); } } } } out.sort_by(|a,b|a.filename.cmp(&b.filename)); out
}
fn get(url: &str)->Result<String,String>{reqwest::blocking::Client::new().get(url).header("User-Agent","vibe-coder-rust").timeout(Duration::from_secs(25)).send().map_err(|e|e.to_string())?.error_for_status().map_err(|e|e.to_string())?.text().map_err(|e|e.to_string())}
fn online_project()->Option<Project>{
    let topics=["game","cli tool","text adventure","automation script","web scraper","productivity tool","puzzle game","calculator","note taking app","weather app","quiz app"];
    let topic=topics.choose(&mut rand::thread_rng())?;
    let url=format!("https://api.github.com/search/repositories?q={}+language%3Apython&sort=stars&per_page=15",topic.replace(' ','+'));
    #[derive(Deserialize)]struct Search{items:Vec<Repo>}; #[derive(Deserialize)]struct Repo{name:String,full_name:String,html_url:String}
    #[derive(Deserialize)]struct File{name:String,size:u64,download_url:Option<String>}
    let data=get(&url).ok()?; let repos:Search=serde_json::from_str(&data).ok()?; let mut candidates=repos.items; candidates.shuffle(&mut rand::thread_rng());
    for repo in candidates.into_iter().take(5){
        let listing=get(&format!("https://api.github.com/repos/{}/contents",repo.full_name)).ok()?;
        let files:Vec<File>=serde_json::from_str(&listing).ok()?; let mut py:Vec<_>=files.into_iter().filter(|f|f.name.ends_with(".py")&&f.size>=4000&&f.size<=40000&&f.download_url.is_some()).collect(); py.shuffle(&mut rand::thread_rng());
        for f in py.into_iter().take(2){if let Some(url)=f.download_url {if let Ok(code)=get(&url){if code.len()>1500 {return Some(Project{name:slug(&repo.name),filename:f.name,code:format!("# Source repository: {}\n# Review its licence before reuse.\n\n{}",repo.html_url,code)});}}}}
    } None
}
fn code_command()->Option<String>{for c in ["code","code.cmd"]{if Command::new(c).arg("--version").stdout(Stdio::null()).stderr(Stdio::null()).status().is_ok(){return Some(c.into())}}None}
fn open_editor(folder:&Path,file:&Path,wait:f64)->Result<(),String>{let c=code_command().ok_or("VS Code 'code' command not found. Add it to PATH.")?; Command::new(c).args(["-n"]).arg(folder).arg(file).spawn().map_err(|e|e.to_string())?; thread::sleep(Duration::from_secs_f64(wait.max(0.0))); Ok(())}
fn focus_ok(file:&str,folder:&str)->bool {
    #[cfg(target_os="linux")] { if let Ok(out)=Command::new("xdotool").args(["getactivewindow","getwindowname"]).output(){let title=String::from_utf8_lossy(&out.stdout);return title.contains(file)&&title.contains(folder)&&title.contains("Visual Studio Code");} false }
    #[cfg(target_os="windows")] { if let Ok(out)=Command::new("powershell").args(["-NoProfile","-Command","(Get-Process Code -ErrorAction SilentlyContinue | Where-Object {$_.MainWindowTitle} | Select-Object -First 1 -ExpandProperty MainWindowTitle)"]).output(){let title=String::from_utf8_lossy(&out.stdout);return title.contains(file)&&title.contains(folder);} false }
    #[cfg(target_os="macos")] { if let Ok(out)=Command::new("osascript").args(["-e","tell application \"System Events\" to get name of first application process whose frontmost is true"]).output(){return String::from_utf8_lossy(&out.stdout).contains("Code");} false }
}
fn sleep_check(d:f64){let end=Instant::now()+Duration::from_secs_f64(d.max(0.0));while Instant::now()<end&&!STOP.load(std::sync::atomic::Ordering::SeqCst){thread::sleep(Duration::from_millis(50));}}
fn type_code(code:&str,slow:f64,char_delay:f64,guard:bool,file:&str,folder:&str)->Result<(),String>{
    let mut enigo=Enigo::new(&Settings::default()).map_err(|e|format!("Keyboard init: {e}"))?;
    let normalized=code.replace("\r\n","\n").replace('\r',"\n");
    for ch in normalized.chars(){if STOP.load(std::sync::atomic::Ordering::SeqCst){return Ok(())} if guard&&!focus_ok(file,folder){return Err("Focus check failed. Typing stopped.".into())}
        match ch { '\n'=>enigo.key(Key::Return,Direction::Click).map_err(|e|e.to_string())?, '\t'=>enigo.key(Key::Tab,Direction::Click).map_err(|e|e.to_string())?, _=>enigo.text(&ch.to_string()).map_err(|e|e.to_string())? }
        sleep_check(char_delay*slow);
    } Ok(())
}
fn next_folder(root:&Path,name:&str)->Result<PathBuf,String>{for n in 1..10000{let f=root.join(format!("{:03}_{}",n,slug(name)));if !f.exists(){fs::create_dir_all(&f).map_err(|e|e.to_string())?;return Ok(f)}}Err("Unable to allocate project folder".into())}
fn main_run(args:Args)->Result<(),String>{
    ctrlc::set_handler(||STOP.store(true,std::sync::atomic::Ordering::SeqCst)).map_err(|e|e.to_string())?;
    let root=if args.keep{let p=expand(&args.out);fs::create_dir_all(&p).map_err(|e|e.to_string())?;p}else{std::env::temp_dir().join(format!("vibe_coder_{}",std::process::id()))};fs::create_dir_all(&root).map_err(|e|e.to_string())?;
    let mut pool=projects();if let Some(d)=args.projects_dir.as_ref(){pool.extend(local_projects(d));}if pool.is_empty(){return Err("No projects found".into())};
    println!("Selected {} built-in/local projects. Ctrl+C stops the run.",pool.len()); if args.dry_run {pool.shuffle(&mut rand::thread_rng());for p in pool.iter().take(5){println!("{}: {} lines, {} bytes",p.name,p.code.lines().count(),p.code.len());}if !args.keep{let _=fs::remove_dir_all(root);}return Ok(())}
    println!("Starting in 5 seconds. Make sure VS Code is visible and ready.");sleep_check(5.0);
    let started=Instant::now();let limit=if args.hours>0.0{Some(Duration::from_secs_f64(args.hours*3600.0))}else{None};let mut q=Vec::<Project>::new();let mut count=0;
    while !STOP.load(std::sync::atomic::Ordering::SeqCst){if limit.map(|d|started.elapsed()>=d).unwrap_or(false){break}let p=if args.online{online_project().unwrap_or_else(||{if q.is_empty(){q=pool.clone();q.shuffle(&mut rand::thread_rng());}q.pop().unwrap()})}else{if q.is_empty(){q=pool.clone();q.shuffle(&mut rand::thread_rng());}q.pop().unwrap()};count+=1;
        let folder=next_folder(&root,&p.name)?;let path=folder.join(&p.filename);fs::write(&path,"").map_err(|e|e.to_string())?;println!("Project {}: {} ({} lines)",count,p.name,p.code.lines().count());
        open_editor(&folder,&path,args.window_wait)?; if !args.no_focus_check&&!focus_ok(&p.filename,folder.file_name().unwrap_or_default().to_string_lossy().as_ref()){return Err("Focus verification failed. No code was typed.".into())}
        type_code(&p.code,args.slowdown.max(0.2),args.char_delay.max(0.0),!args.no_focus_check,&p.filename,folder.file_name().unwrap_or_default().to_string_lossy().as_ref())?;
        if STOP.load(std::sync::atomic::Ordering::SeqCst){break}
        if !args.keep_windows{let mut enigo=Enigo::new(&Settings::default()).map_err(|e|e.to_string())?;let (ctrl,shift,w)= (Key::Control,Key::Shift,Key::Unicode('w'));let _=enigo.key(ctrl,Direction::Press);let _=enigo.key(shift,Direction::Press);let _=enigo.key(w,Direction::Click);let _=enigo.key(shift,Direction::Release);let _=enigo.key(ctrl,Direction::Release);}
        if !args.keep&&!args.keep_windows{let _=fs::remove_dir_all(&folder);}println!("Finished {}",p.name);sleep_check(rand::thread_rng().gen_range(2.0..5.0));
    }
    if !args.keep{let _=fs::remove_dir_all(&root);}println!("Stopped or time limit reached.");Ok(())
}
fn main(){let args=Args::parse();if let Err(e)=main_run(args){eprintln!("Error: {e}");std::process::exit(1)}}
