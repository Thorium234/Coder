# Vibe Coder Rust

A Rust implementation of a VS Code typing automation controller that opens Python project files and types them into the editor. Python remains the target language for the projects; Rust is the controller.

## Features

- Embedded set of Python projects
- Optional local `.py` project collection
- Optional GitHub repository search and file download mode
- Runtime limit and typing delay controls
- Project output retention or temporary cleanup
- VS Code window opening
- Ctrl+C shutdown
- Focus title checks on supported systems (Linux requires `xdotool`; Windows title check uses PowerShell)
- Dry run

## Requirements

- Rust toolchain (Cargo)
- Visual Studio Code and the `code` command in PATH
- Keyboard automation permissions on your OS
- Linux: `xdotool` for active window title checks

## Setup

```sh
git clone https://github.com/Thorium234/Coder.git
cd Coder
cargo build --release
```

## Run

```sh
cargo run --release
cargo run --release -- --dry-run
cargo run --release -- --hours 1
cargo run --release -- --slowdown 1.5
cargo run --release -- --char-delay 0.25
cargo run --release -- --projects-dir ./python_projects
cargo run --release -- --online
cargo run --release -- --keep --out ~/vibe_projects
cargo run --release -- --keep-windows
cargo run --release -- --window-wait 10
cargo run --release -- --no-focus-check
```

## Options

| Option | Meaning |
|---|---|
| `--dry-run` | List sample projects without opening editor or typing |
| `--hours` | Run for this many hours, zero means no time limit |
| `--slowdown` | Multiplier for the typing delay |
| `--char-delay` | Delay between typed characters, seconds |
| `--projects-dir` | Load `.py` files from a folder |
| `--online` | Search GitHub and download eligible Python files |
| `--keep` | Retain generated project folders |
| `--out` | Retention destination |
| `--keep-windows` | Leave VS Code windows open after each project |
| `--window-wait` | Delay after opening VS Code |
| `--no-focus-check` | Disable focus-title checks, use cautiously |

## Safety and limitations

This tool sends keyboard input to the active desktop. Confirm the editor window is the intended target before running. The title-based focus check is platform-dependent and is not a complete safety guarantee. `--no-focus-check` disables this guard. Ctrl+C stops the run.

The current Rust port does not yet implement the original pause/resume hotkey, typo simulation, or Anthropic API project generation. Online mode uses GitHub repository/file retrieval only. The Rust source has not been compiled in this environment because Cargo was unavailable; compile and test it locally before relying on it.

## Licence

Check the licence of any source code fetched from GitHub before reusing it.
