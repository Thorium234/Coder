module vibe-coder

go 1.23.2
