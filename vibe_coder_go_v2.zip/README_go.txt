Vibe Coder Go, V2

The controller is written in Go. It types Python project snippets into VS Code.

Files:
  vibe_coder.go
  builtin_projects.json

Requirements:
  Go 1.23 or newer
  VS Code with the `code` command available on PATH
  Robotgo prerequisites for your operating system (see Robotgo documentation)

Setup:
  1. Extract this archive.
  2. Open a terminal in the extracted directory.
  3. Run:
       go mod init vibe-coder
       go get github.com/go-vgo/robotgo
       go run . --dry-run
  4. If the dry-run is satisfactory, try a short real run:
       go run . --hours 0.02 --keep --keep-windows

If go.mod already exists, do not run go mod init again.

Options:
  --dry-run             Preview one selected project without opening VS Code or typing
  --hours 3             Stop after 3 hours; zero means no time limit
  --slowdown 1.5        Slow down typing by 1.5x
  --projects-dir ./code  Include local .py files from this directory
  --online               Attempt to fetch a public Python file from GitHub
  --keep                 Keep generated project files
  --out ~/vibe_projects  Destination when --keep is enabled
  --keep-windows         Do not close VS Code windows after typing
  --window-wait 12       Wait this many seconds after VS Code opens
  --no-focus-check       Disable the active-window title check (unsafe)

Safety and limitations:
  Keyboard simulation is inherently risky. Start with --dry-run, then a short run.
  The title check is best-effort and depends on Robotgo/OS support. It is not a
  complete guarantee that the correct editor is focused. If the check fails,
  the program stops before typing. --no-focus-check bypasses this safeguard.
  Ctrl+C stops the process. Pause/resume hotkeys from the original Python version
  have not been ported in this version.
  Online mode downloads public GitHub files and is not an Anthropic code-generation
  port. Check the source project's licence before reuse.
  This package has not been build-verified in this environment because the
  Robotgo dependency could not be fetched here.
